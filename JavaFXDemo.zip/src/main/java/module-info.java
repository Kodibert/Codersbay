module at.codersbay.javafxdemo {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;

    opens at.codersbay.javafxdemo to javafx.fxml;
    exports at.codersbay.javafxdemo;
}