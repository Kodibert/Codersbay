package at.codersbay.javafxdemo;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class HelloController {
    CalculatorModel myCalculation;
    private Integer counter;

    @FXML
    private TextField entry;

    @FXML
    private Label welcomeText;

    @FXML
    protected void onCountButtonClick() {
        welcomeText.setText("Current count is: " + counter);
        counter++;
    }

    @FXML
    protected void onButtonClick0() {
        myCalculation.addKey('0');
        entry.setText(myCalculation.getEntry());
    }

    @FXML
    protected void onButtonClickMinus() {
        myCalculation.addKey('-');
        entry.setText(myCalculation.getEntry());
    }

    @FXML
    protected void onButtonClickChangeSign() {
        String pre = "-1*(";
        String post = ")";
        myCalculation.setEntry(pre + entry.getText() + post);
        entry.setText(myCalculation.getEntry());
    }

    @FXML
    protected void onButtonClickClearAll() {
        entry.setText("");
        myCalculation.setEntry("");
    }

    public HelloController() {
        counter = 0;
        myCalculation = new CalculatorModel();
    }
}